let cursos=[
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"ingles",
        "horario_modalidad":"TM",
        "descripcion_horario":"8AM-12PM Virtual",
        "direccion":"av pueyrredon 852",
        "localidad":"CABA",
        "mail":"JoinUs@gmail.com",
        "precio":"1000",
        "imagen":"establecimiento.jpg"
    },
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"portugues",
        "horario_modalidad":"TN",
        "descripcion_horario":"6AM-9PM Virtual",
        "direccion":"av luro 1254",
        "localidad":"CABA",
        "mail":"Further@gmail.com",
        "precio":"1000",
        "imagen":"establecimiento1.jpg"
    },
    {
        "provincia":"C",
        "nombre_provincia":"Cordoba",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TT",
        "descripcion_horario":"2PM-6PM Virtual",
        "direccion":"av wea 352",
        "localidad":"Cordoba",
        "mail":"Futher@gmail.com",
        "precio":"1500",
        "imagen":"establecimiento2.jpg"
    }
];




$(document).ready(function(){
    $("#provincia").on("keyup", function() {
        
      var value = $(this).val().toLowerCase();
      filtrar(value);
      
    });
});

//cursos.filter(cursos=>cursos.establecimiento=="1"&&cursos.idioma=="ingles")
function filtrar(value){
    
    
    //2.filtrar el array de objetos
    let filtrado=cursos.filter(cursos=>cursos.nombre_provincia.toLowerCase().indexOf(value)>-1);
    
   
    //3.vaciar el section de cursos empty()
   $("#resultados").empty();

    //4.recorrer el array y lo va a llenar de datos append()
    if(filtrado.length == 0){
        $("#resultados").append(`
            <section class="contenedor">
                <article>
                    <p><b> No hay resultados .</b></p>
                </article>
            </section>
        `);
        $("#precio").val(0);
    }else{
        filtrado.forEach(curso => {
            $("#resultados").append(`
                
                <section class="contenedor">
                <article> 
                    <img src="img/${curso.imagen}">
                </article>
                <article>
                    <h2>${curso.nombre_establecimiento}</h2>
                    <p><b>Nombre del establecimiento: </b>${curso.nombre_establecimiento}</p>
                    <p><b>Dirección: </b>${curso.direccion}</p>
                    <p><b>Localidad: </b>${curso.localidad}</p>
                    <p><b>Provincia: </b>${curso.nombre_provincia}</p>
                    <p><b>Email: </b>${curso.mail}</p>
                    <form action="detalle_establecimientos.html">
                        <button type="submit">Ver detalle</button>
                      </form>
                </article>
        </section>


            `);
           
        });
        
    }

    
}