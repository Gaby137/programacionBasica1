let formulario;
let regexEmail=/^[0-9a-zA-Z._.-]+\@[0-9a-zA-Z._.-]+\.[0-9a-zA-Z]+$/
let regexTelefono=/^[0-9]+\-[0-9]+$/
window.onload=function(){
    formulario=document.getElementById("form");
    formulario.onsubmit=function(e){
        e.preventDefault();
        validar();
    }
    
}
let maxcaracteres=1000;
function cuenta(){

        $("#caracteres").val($("#consulta").val().length);
        $("#caracteres-faltantes").val(maxcaracteres-$("#consulta").val().length)
    
}
function validar(){
    let error=false;
    let mensajesError="";
    if(document.getElementById("nombre").value==""){
        error=true;
        mensajesError+="<p>El nombre no puede estar vacio.</p>";
    }
    if(document.getElementById("nombre").value==""){
        error=true;
        mensajesError+="<p>El apellido no puede estar vacio.</p>";
    }
    if(!regexEmail.test(document.getElementById("email").value)){
        error=true;
        mensajesError+="<p>Tiene que ser un email valido.</p>";
    }
    if(!regexTelefono.test(document.getElementById("telefono").value)){
        error=true;
        mensajesError+="<p>El telefono tiene que contener 8 digitos y un guion en el medio</p>";
    }
    if(document.getElementById("consulta").value.length>maxcaracteres){
        error=true;
        mensajesError+="<p>El maximo es 1000 caracteres</p>";
    }
    if(error){
        document.getElementById("mensaje").innerHTML=mensajesError;
    }else{
        formulario.submit();
        alert("Envio exitoso");
    }
}




