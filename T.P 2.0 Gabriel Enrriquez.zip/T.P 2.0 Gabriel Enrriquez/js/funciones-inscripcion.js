let cursos=[
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"ingles",
        "horario_modalidad":"TM",
        "descripcion_horario":"8AM-12PM Virtual",
        "direccion":"av pueyrredon 852",
        "localidad":"CABA",
        "mail":"JoinUs@gmail.com",
        "precio":"1000",
        "imagen":"establecimiento.jpg",
        "nivel":"I",
        "fecha_inicio":"01/03/2021"
    },
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"portugues",
        "horario_modalidad":"TN",
        "descripcion_horario":"6AM-9PM Virtual",
        "direccion":"av luro 1254",
        "localidad":"CABA",
        "mail":"Further@gmail.com",
        "precio":"3000",
        "imagen":"establecimiento1.jpg",
        "nivel":"II",
        "fecha_inicio":"01/06/2021"
    },
    {
        "provincia":"C",
        "nombre_provincia":"Cordoba",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TT",
        "descripcion_horario":"2PM-6PM Virtual",
        "direccion":"av wea 352",
        "localidad":"Cordoba",
        "mail":"Futher@gmail.com",
        "precio":"1500",
        "imagen":"establecimiento2.jpg",
        "nivel":"VI",
        "fecha_inicio":"01/12/2021"
    }
];

$(document).ready(function() {
  
    console.log(localStorage);

    darDetalle(localStorage);


   
});

function darDetalle(local){
    $("#inscripcionDescripcion").empty();

    let filtrado=cursos.filter(cursos=>cursos.provincia==local.provincia&&cursos.establecimiento==local.establecimiento&&cursos.precio==local.precio);
    console.log(filtrado);
    
    $("#inscripcionDescripcion").append(`
            <h1>INSCRIPCION</h1>
            <p>Inscripcion al curso de idioma ${filtrado[0].idioma}  en la sede Establecimiento ${filtrado[0].nombre_establecimiento}  en el horario ${filtrado[0].descripcion_horario} </p>
            <p>El curso inicia el ${filtrado[0].fecha_inicio} </p>
            <p>El precio es $${filtrado[0].precio} .</p>
    `);
}













let formulario;
let regexEmail=/^[0-9a-zA-Z._.-]+\@[0-9a-zA-Z._.-]+\.[0-9a-zA-Z]+$/
window.onload=function(){
    formulario=document.getElementById("form");
    formulario.onsubmit=function(e){
        e.preventDefault();
        validar();
    }
    
}
function validar(){
    let error=false;
    let mensajesError="";
    if(document.getElementById("nombre").value==""){
        error=true;
        mensajesError+="<p>El nombre no puede estar vacio.</p>";
    }
    if(document.getElementById("apellido").value==""){
        error=true;
        mensajesError+="<p>El apellido no puede estar vacio.</p>";
    }
    if(!regexEmail.test(document.getElementById("email").value)){
        error=true;
        mensajesError+="<p>Tiene que ser un email valido.</p>";
    }
    if(document.getElementById("telefono").value==""){
        error=true;
        mensajesError+="<p>El telefono no puede estar vacio.</p>";
    }
    if(document.getElementById("provincia").value==""){
        error=true;
        mensajesError+="<p>La provincia no puede estar vacio.</p>";
    }
    if(document.getElementById("ciudad").value==""){
        error=true;
        mensajesError+="<p>La ciudad no puede estar vacio.</p>";
    }
    if(error){
        document.getElementById("mensaje").innerHTML=mensajesError;
    }else{
        formulario.submit();
    }
}

   
