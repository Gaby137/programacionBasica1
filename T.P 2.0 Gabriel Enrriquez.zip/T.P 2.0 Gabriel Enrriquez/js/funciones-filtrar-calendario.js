let cursos=[
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"ingles",
        "horario_modalidad":"TM",
        "descripcion_horario":"8AM-12PM Virtual",
        "direccion":"av pueyrredon 852",
        "localidad":"CABA",
        "mail":"JoinUs@gmail.com",
        "precio":"3000",
        "imagen":"establecimiento.jpg",
        "nivel":"I",
        "fecha_inicio":"01/03/2021"
    },
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"portugues",
        "horario_modalidad":"TN",
        "descripcion_horario":"6AM-9PM Virtual",
        "direccion":"av luro 1254",
        "localidad":"CABA",
        "mail":"Further@gmail.com",
        "precio":"1000",
        "imagen":"establecimiento1.jpg",
        "nivel":"II",
        "fecha_inicio":"01/06/2021"
    },
    {
        "provincia":"C",
        "nombre_provincia":"Cordoba",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TT",
        "descripcion_horario":"2PM-6PM Virtual",
        "direccion":"av wea 352",
        "localidad":"Cordoba",
        "mail":"Futher@gmail.com",
        "precio":"1500",
        "imagen":"establecimiento2.jpg",
        "nivel":"VI",
        "fecha_inicio":"01/12/2021"
    }
];




$(document).ready(function() {
    $("select").change(function(event) {
        event.preventDefault();
        filtrar();
    });
});


//cursos.filter(cursos=>cursos.establecimiento=="1"&&cursos.idioma=="ingles")
function filtrar(){

    alert("filtrando...");
    //1.obtener los valores de los selects val()
   
    const establecimiento=$("#establecimiento").val();
    const idioma=$("#idiomas").val();
 
    //2.filtrar el array de objetos
    let filtrado=cursos.filter(cursos=>cursos.establecimiento==establecimiento || cursos.idioma==idioma);
   
    //3.vaciar el section de cursos empty()
    $( ".contenedor-calendario" ).empty();

    //4.recorrer el array y lo va a llenar de datos append()
    if(filtrado.length == 0){
        $("#results").append(`
        <article>
            <p><b> No hay resultados .</b></p>
        </article>
        `);
    }else{
        
        filtrado.forEach(curso => {
            $("#results").append(`
                    <article>
                        <img src="img/${curso.imagen}">
                    </article>
                    <article>
                        <h4>IDIOMA - NIVEL ${curso.nivel}</h4>
                        <p>Modalidad:		${curso.descripcion_horario.split(" ")[1]}</p>
                        <p>Días y horarios: ${curso.descripcion_horario.split(" ")[0]}</p>
                        <p>Fecha de inicio: ${curso.fecha_inicio}</p>
                        <p><b>Precio:$${curso.precio}</b></p>
                        <form action="inscripcion.html">
                            <button type="submit">Inscribirse</button>
                        </form>
                    </article>       
                    
            `);
        });
        
    }

    
}