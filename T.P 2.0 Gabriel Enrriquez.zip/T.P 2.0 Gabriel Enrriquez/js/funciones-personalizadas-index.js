let cursos=[
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"ingles",
        "horario_modalidad":"TM",
        "descripcion_horario":"8AM-12PM Virtual",
        "direccion":"av pueyrredon 852",
        "localidad":"CABA",
        "mail":"JoinUs@gmail.com",
        "precio":"1000"
    },
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TN",
        "descripcion_horario":"6AM-9PM Virtual",
        "direccion":"av luro 1254",
        "localidad":"CABA",
        "mail":"Further@gmail.com",
        "precio":"1000"
    },
    {
        "provincia":"C",
        "nombre_provincia":"Cordoba",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TT",
        "descripcion_horario":"2PM-6PM Virtual",
        "direccion":"av wea 352",
        "localidad":"Cordoba",
        "mail":"Futher@gmail.com",
        "precio":"1500"
    }
];

$(document).ready(function() {
  
 
    var fillSecondary = function(){
		var selected = $('#provincia').val();
		
        $('#establecimiento').empty();
        $('#idiomas').empty();
        $('#horario_modalidad').empty();
        switch (selected) {
            case "B":
                    $('#establecimiento').append('<option value="'+"1"+'">'+"Join Us!"+'</option>');
                    $('#establecimiento').append('<option value="'+"2"+'">'+"Further"+'</option>');
                    $('#idiomas').append('<option value="'+"ingles"+'">'+"Ingles"+'</option>');
                    $('#idiomas').append('<option value="'+"portugues"+'">'+"Portugues"+'</option>');
                    //<option value="2">Further</option>
                    $('#horario_modalidad').append('<option value="'+"TM"+'">'+"8AM-12PM Virtual"+'</option>');
                    $('#horario_modalidad').append('<option value="'+"TN"+'">'+"6PM-9PM Virtual"+'</option>');
                break;
            case "C":
                $('#establecimiento').append('<option value="'+"2"+'">'+"Further"+'</option>');    
                $('#establecimiento').append('<option value="'+"3"+'">'+"DoneWise"+'</option>');
                $('#idiomas').append('<option value="'+"frances"+'">'+"Frances"+'</option>');
                $('#idiomas').append('<option value="'+"ingles"+'">'+"Ingles"+'</option>');
                $('#horario_modalidad').append('<option value="'+"TT"+'">'+"2PM-6PM Virtual"+'</option>');
                $('#horario_modalidad').append('<option value="'+"TN"+'">'+"6PM-9PM Virtual"+'</option>');
                    break;
            case "E":
                $('#establecimiento').append('<option value="'+"2"+'">'+"Further"+'</option>');
                $('#establecimiento').append('<option value="'+"3"+'">'+"DoneWise"+'</option>');
                $('#establecimiento').append('<option value="'+"4"+'">'+"ABALenguas"+'</option>');
                $('#idiomas').append('<option value="'+"ingles"+'">'+"Ingles"+'</option>');
                $('#idiomas').append('<option value="'+"portugues"+'">'+"Portugues"+'</option>');
                $('#idiomas').append('<option value="'+"frances"+'">'+"Frances"+'</option>');
                $('#horario_modalidad').append('<option value="'+"TM"+'">'+"8AM-12PM Virtual"+'</option>');
                $('#horario_modalidad').append('<option value="'+"TT"+'">'+"2PM-6PM Virtual"+'</option>');
                $('#horario_modalidad').append('<option value="'+"TN"+'">'+"6PM-9PM Virtual"+'</option>');
                    break;
            default:
                break;
        }
		
	}
	$('#provincia').change(fillSecondary);
	fillSecondary();

    $("#provincia").change(function(){
        cambiarProvincia($(this).val());
    });
    $('#establecimiento').change(function(){
        cambiarEstablecimiento($(this).val());
    });
    $('#idiomas').change(function(){
        filtrar();
    });
    $('#horario_modalidad').change(function(){
        filtrar();
    });

    
    $(window).unload(saveSettings);
    loadSettings();



   
});

function loadSettings() {
    $('#provincia').val(localStorage.provincia);
    $('#establecimiento').val(localStorage.establecimiento);
    $('#idiomas').val(localStorage.idiomas);
    $('#horario_modalidad').val(localStorage.horario_modalidad);
    $('#precio').val(localStorage.precio);
}

function saveSettings() {
    localStorage.provincia = $('#provincia').val();
    localStorage.establecimiento = $('#establecimiento').val();
    localStorage.horario_modalidad = $('#horario_modalidad').val();
    localStorage.precio = $("#precio").val();
}
   


function cambiarProvincia(valor){
    var nomProv="";
    switch (valor) {
        case "B":
            nomProv="Buenos Aires"
            break;
        case "C":
            nomProv="Cordoba"
            break;
        case "E":
            nomProv="Entre Rios"
            break;
    
        default:
            break;
    }
    
    $("#nomProv").empty();
    $("#nomEst").empty();
    $("#nomProv").append(nomProv);
    //$("#precio").val(curso.precio);
    filtrar();
}

function cambiarEstablecimiento(valor){
    var nomEst="";
    switch (valor) {
        case "1":
            nomEst="Join Us!"
            break;
        case "2":
            nomEst="Further"
            break;
        case "3":
            nomEst="DoneWise"
            break;
        case "4":
            nomEst="ABALenguas"
            break;
        default:
            break;
    }
    $("#nomEst").empty();
    $("#nomEst").append(nomEst);
    filtrar();
}


function filtrar(){
    //1.obtener los valores de los selects val()
    const provincia=$("#provincia").val();
    const establecimiento=$("#establecimiento").val();
    const idioma=$("#idiomas").val();
    const horario_modalidad=$("#horario_modalidad").val();
 
    //2.filtrar el array de objetos
    let filtrado=cursos.filter(cursos=>cursos.provincia==provincia&&cursos.establecimiento==establecimiento&&cursos.idioma==idioma&&cursos.horario_modalidad==horario_modalidad);
   
    //3.vaciar el section de cursos empty()
   $("#direcion").empty();
   $("#loca").empty();
   $("#mail").empty();

    //4.recorrer el array y lo va a llenar de datos append()
    
        filtrado.forEach(curso => {
            $("#direcion").append(curso.direccion);
            $("#loca").append(curso.localidad);
            $("#mail").append(curso.mail);
            $("#precio").val(curso.precio);
        });
        
    

    
}