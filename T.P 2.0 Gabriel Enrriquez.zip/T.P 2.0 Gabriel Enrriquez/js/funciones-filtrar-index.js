let cursos=[
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"ingles",
        "horario_modalidad":"TM",
        "descripcion_horario":"8AM-12PM Virtual",
        "direccion":"av pueyrredon 852",
        "localidad":"CABA",
        "mail":"JoinUs@gmail.com",
        "precio":"1000"
    },
    {
        "provincia":"B",
        "nombre_provincia":"Buenos aires",
        "establecimiento":"1",
        "nombre_establecimiento":"Join Us!",
        "idioma":"portugues",
        "horario_modalidad":"TN",
        "descripcion_horario":"6AM-9PM Virtual",
        "direccion":"av luro 1254",
        "localidad":"CABA",
        "mail":"Further@gmail.com",
        "precio":"1000"
    },
    {
        "provincia":"C",
        "nombre_provincia":"Cordoba",
        "establecimiento":"2",
        "nombre_establecimiento":"Further",
        "idioma":"portugues",
        "horario_modalidad":"TT",
        "descripcion_horario":"2PM-6PM Virtual",
        "direccion":"av wea 352",
        "localidad":"Cordoba",
        "mail":"Futher@gmail.com",
        "precio":"1500"
    }
];




$(document).ready(function() {
    $("#filtrar").click(function(event) {
        event.preventDefault();
        //alert("The required page will not be open");
        filtrar();
    });
});

//cursos.filter(cursos=>cursos.establecimiento=="1"&&cursos.idioma=="ingles")
function filtrar(){
    //1.obtener los valores de los selects val()
    const provincia=$("#provincia").val();
    const establecimiento=$("#establecimiento").val();
    const idioma=$("#idiomas").val();
    const horario_modalidad=$("#horario_modalidad").val();
 
    //2.filtrar el array de objetos
    let filtrado=cursos.filter(cursos=>cursos.provincia==provincia&&cursos.establecimiento==establecimiento&&cursos.idioma==idioma&&cursos.horario_modalidad==horario_modalidad);
   
    //3.vaciar el section de cursos empty()
   $("#cursos").empty();

    //4.recorrer el array y lo va a llenar de datos append()
    if(filtrado.length == 0){
        $("#cursos").append(`
        <article>
            <p><b> No hay resultados .</b></p>
        </article>
        `);
        $("#precio").val(0);
    }else{
        filtrado.forEach(curso => {
            $("#cursos").append(`
                <article>
                    <p><b> Nombre del establecimiento: </b>${curso.nombre_establecimiento}</p>
                    <p><b> Dirección: </b>${curso.direccion}</p>
                    <p><b>Localidad: </b>${curso.localidad}</p>
                    <p><b>Provincia: </b>${curso.nombre_provincia}</p>
                    <p><b>Email: </b>${curso.mail}</p>
                </article>
            `);
            $("#precio").val(curso.precio);
        });
        
    }

    
}