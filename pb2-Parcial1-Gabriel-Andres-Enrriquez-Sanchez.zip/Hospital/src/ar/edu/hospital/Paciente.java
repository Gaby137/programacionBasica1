package ar.edu.hospital;

public class Paciente {
	private String nombre;
	private String apellido;
	private Integer dni;
	private TipoDePaciente tipoDePaciente;
	private Tratamiento tipoDeTratamiento;

	public Paciente(String nombre, String apellido, Integer dni, TipoDePaciente tipoDePaciente,
			Tratamiento tipoDeTratamiento) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.tipoDeTratamiento = tipoDeTratamiento;
		this.tipoDePaciente = tipoDePaciente;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public Tratamiento getTipoDeTratamiento() {
		return tipoDeTratamiento;
	}

	public void setTipoDeTratamiento(Tratamiento tipoDeTratamiento) {
		this.tipoDeTratamiento = tipoDeTratamiento;
	}

	public TipoDePaciente getTipoDePaciente() {
		return tipoDePaciente;
	}

	public void setTipoDePaciente(TipoDePaciente tipoDePaciente) {
		this.tipoDePaciente = tipoDePaciente;
	}

}
