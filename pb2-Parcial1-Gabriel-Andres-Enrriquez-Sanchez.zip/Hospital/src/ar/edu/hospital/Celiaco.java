package ar.edu.hospital;

public class Celiaco extends Paciente {

	public Celiaco(String nombre, String apellido, Integer dni, TipoDePaciente tipoDePaciente,
			Tratamiento tipoDeTratamiento) {
		super(nombre, apellido, dni, tipoDePaciente, tipoDeTratamiento);
		// TODO Auto-generated constructor stub
	}

}
