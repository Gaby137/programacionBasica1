package ar.edu.hospital;

public enum Tratamiento {
	NADA, QUIMIOTERAPIA, RADIOTERAPIA;
}
