package ar.edu.hospital;

public class Ingrediente {
	private String descripcion;

	public Ingrediente() {

	}

	public Ingrediente(String descripcion) {
		super();
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
