package ar.edu.hospital;

public class Diabetico extends Paciente {

	private Boolean insulina;

	public Diabetico(String nombre, String apellido, Integer dni, TipoDePaciente tipoDePaciente,
			Tratamiento tipoDeTratamiento) {
		super(nombre, apellido, dni, tipoDePaciente, tipoDeTratamiento);
		this.insulina = false;
	}

	public Boolean getInsulina() {
		return insulina;
	}

	public void setInsulina(Boolean insulina) {
		this.insulina = insulina;
	}

}
