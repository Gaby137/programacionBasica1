package ar.edu.hospital;

public enum TipoDePaciente {
	DIABETICO, CELIACO, ONCOLOGICO, HIPERTENSO, GENERALE;
}
