package ar.edu.hospital;

public class DiabeticoTipo1 extends Diabetico {

	public DiabeticoTipo1(String nombre, String apellido, Integer dni, TipoDePaciente tipoDePaciente,
			Tratamiento tipoDeTratamiento) {
		super(nombre, apellido, dni, tipoDePaciente, tipoDeTratamiento);
		// TODO Auto-generated constructor stub
	}

}
