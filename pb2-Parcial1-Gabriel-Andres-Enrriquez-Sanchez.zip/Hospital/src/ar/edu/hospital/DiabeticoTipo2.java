package ar.edu.hospital;

public class DiabeticoTipo2 extends Diabetico {

	public DiabeticoTipo2(String nombre, String apellido, Integer dni, TipoDePaciente tipoDePaciente,
			Tratamiento tipoDeTratamiento) {
		super(nombre, apellido, dni, tipoDePaciente, tipoDeTratamiento);
		// TODO Auto-generated constructor stub
	}

}
