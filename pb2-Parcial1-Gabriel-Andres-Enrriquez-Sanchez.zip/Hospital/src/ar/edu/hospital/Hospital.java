package ar.edu.hospital;

import java.util.HashSet;
import java.util.Set;

public class Hospital {
	private String titulo;

	private Set<Paciente> listaDePacientes;

	public Hospital(String titulo) {
		super();
		this.titulo = titulo;
		this.listaDePacientes = new HashSet<>();
	}

	public Boolean agregarPaciente(Paciente p) {
		Boolean agregado = false;
		if (p != null) {
			listaDePacientes.add(p);
		}
		return agregado;
	}

	public Boolean alimentarPaciente(Paciente p, Plato plato) {
		Boolean alimentado = true;
		Ingrediente i = new Ingrediente();

		for (Paciente paciente : listaDePacientes) {
			if (p.equals(paciente)) {
				if (p instanceof Diabetico) {
					for (String a : plato.getListaDeIngredientes()) {
						if (a != "azucar") {
							alimentado = false;
						}
					}
				}
				if (p instanceof Oncologico) {
					if (p.getTipoDeTratamiento() != Tratamiento.QUIMIOTERAPIA
							|| p.getTipoDeTratamiento() != Tratamiento.RADIOTERAPIA) {
						alimentado = false;
					}
				}
			}

		}
		return alimentado;
	}
}
