package ar.edu.hospital;

import java.util.ArrayList;
import java.util.List;

public class Plato {
	private String titulo;
	private List<String> listaDeIngredientes;
	private Elaboracion procesoDeElaboracion;

	public Plato(String titulo, Elaboracion procesoDeElaboracion) {
		super();
		this.titulo = titulo;
		this.listaDeIngredientes = new ArrayList<>();
		this.procesoDeElaboracion = procesoDeElaboracion;
	}

	public void ingresarIngrediente(String i) {
		this.listaDeIngredientes.add(i);
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public List<String> getListaDeIngredientes() {
		return listaDeIngredientes;
	}

	public void setListaDeIngredientes(List<String> listaDeIngredientes) {
		this.listaDeIngredientes = listaDeIngredientes;
	}

	public Elaboracion getProcesoDeElaboracion() {
		return procesoDeElaboracion;
	}

	public void setProcesoDeElaboracion(Elaboracion procesoDeElaboracion) {
		this.procesoDeElaboracion = procesoDeElaboracion;
	}

}
