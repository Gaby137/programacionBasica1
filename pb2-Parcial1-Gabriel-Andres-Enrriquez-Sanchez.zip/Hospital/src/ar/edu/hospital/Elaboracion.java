package ar.edu.hospital;

public enum Elaboracion {

	HORNO, FRITO, OLLA, CRUDO;
}
