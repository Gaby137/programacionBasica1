package ar.edu.hospital;

import static org.junit.Assert.assertFalse;

import org.junit.Test;

public class TestHospital {

	@Test
	public void queNoSePuedaAlimentarAUnPacienteDiabeticoConAzucar() {
		Hospital h1 = new Hospital("centro");

		Paciente p1 = new Diabetico("pepe", "sanche", 123, TipoDePaciente.DIABETICO, Tratamiento.NADA);
		Paciente p2 = new Oncologico("fer", "alva", 321, TipoDePaciente.ONCOLOGICO, Tratamiento.QUIMIOTERAPIA);

		Plato plato = new Plato("Guiso", Elaboracion.OLLA);
		h1.agregarPaciente(p1);
		plato.ingresarIngrediente("azucar");

		assertFalse(h1.alimentarPaciente(p1, plato));
		assertFalse(h1.alimentarPaciente(p2, plato));

	}

}
