package ar.edu.panini;

public class FiguritaRepetida extends Exception {
	public FiguritaRepetida(String msg) {
		super(msg);
	}
}
