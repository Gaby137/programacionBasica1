package ar.edu.panini;

public class CodigoExistente extends Exception {
	public CodigoExistente (String msg) {
		super(msg);
	}
}
