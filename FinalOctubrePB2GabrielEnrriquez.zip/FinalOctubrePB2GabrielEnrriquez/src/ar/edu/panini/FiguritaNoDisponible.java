package ar.edu.panini;

public class FiguritaNoDisponible extends Exception {
	public FiguritaNoDisponible(String msg) {
		super(msg);
	}
}
