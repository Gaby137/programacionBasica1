package ar.edu.montacarga;

import java.util.ArrayList;
import java.util.List;

public class Montacargas {
	static final Double MAX_PESO = 200.0;
	private Double acumPeso;
	private List<Carga> cargas;

	public Montacargas() {
		super();
		this.cargas = new ArrayList<>();
		this.acumPeso = 0.0;
	}

	public Boolean cargar(Carga a) {
		Boolean cargo = false;
		if (a.getPeso() <= MAX_PESO && acumPeso <= MAX_PESO) {
			acumPeso += a.getPeso();
			cargo = true;
			cargas.add(a);
		}
		return cargo;
	}

	public Double getAcumPeso() {
		return acumPeso;
	}

	public void setAcumPeso(Double acumPeso) {
		this.acumPeso = acumPeso;
	}

}
