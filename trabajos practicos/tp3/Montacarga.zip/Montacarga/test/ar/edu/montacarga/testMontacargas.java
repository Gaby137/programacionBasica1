package ar.edu.montacarga;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class testMontacargas {

	@Test
	public void Cargar() {

		Carga c1 = new Carga("persona", 100.0);
		Carga c2 = new Carga("carpincho", 100.0);
		Montacargas m1 = new Montacargas();
		m1.cargar(c1);
		m1.cargar(c2);
		assertEquals(200.0, m1.getAcumPeso(), 0.01);

	}

}
