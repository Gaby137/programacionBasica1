package ar.edu.buscaminas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class testBuscaminas {

	@Test
	public void siUnaCasillaEsBomba() {
		char[][] matriz0 = { { '1', '*', '1' }, { '1', '2', '1' }, { '0', '1', '*' } };
		Posicion p1 = new Posicion(0, 1);
		assertEquals('*', matriz0[p1.getX()][p1.getY()]);
	}

	@Test
	public void siUnaCasillaNoEsBomba() {
		char[][] matriz0 = { { '1', '*', '1' }, { '1', '2', '1' }, { '0', '1', '*' } };
		Posicion p1 = new Posicion(1, 0);
		assertTrue(matriz0[p1.getX()][p1.getY()] != '*');
	}

	@Test
	public void cantidadDeBombasAlrededorLat() {
		char[][] matriz0 = { { '1', '*', '1' }, { '1', '2', '1' }, { '0', '1', '*' } };
		Posicion p1 = new Posicion(1, 0);
		Buscaminas b1 = new Buscaminas(matriz0, 3);
		b1.cantidadDeMinasEnUnaPosicion(p1);

	}

	@Test
	public void cantidadDeBombasAlrededorLat3x3() {
		char[][] matriz0 = { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8', '9' } };
		Posicion p1 = new Posicion(2, 2);
		Buscaminas b1 = new Buscaminas(matriz0, 3);
		b1.cantidadDeMinasEnUnaPosicion(p1);

	}

	@Test
	public void cantidadDeBombasAlrededorLat4x4() {
		char[][] matriz0 = { { '1', '1', '1', '1' }, { '2', '2', '2', '2' }, { '3', '3', '3', '3' },
				{ '4', '4', '4', '4' } };
		Posicion p1 = new Posicion(3, 3);
		Buscaminas b1 = new Buscaminas(matriz0, 4);
		b1.cantidadDeMinasEnUnaPosicion(p1);

	}

	@Test
	public void cantidadDeBombasAlrededor() {
		char[][] matriz0 = { { '1', '*', '1', '1' }, { '1', '2', '1', '1' }, { '3', '4', '1', '1' },
				{ '5', '6', '1', '1' } };
		Posicion p1 = new Posicion(2, 3);
		Buscaminas b1 = new Buscaminas(matriz0, 4);
		b1.cantidadDeMinasEnUnaPosicion(p1);

	}

	@Test
	public void testNivel1() {

		Buscaminas b1 = new Buscaminas(1);
		b1.imprimirMatriz();

	}

	@Test
	public void testNivel2() {

		Buscaminas b1 = new Buscaminas(2);
		b1.imprimirMatriz();

	}

	@Test
	public void testNivel3() {

		Buscaminas b1 = new Buscaminas(3);
		b1.imprimirMatriz();

	}

	@Test
	public void testDeJuego() {
		Buscaminas b1 = new Buscaminas(1);
		b1.turno(new Posicion(0, 0));
		b1.turno(new Posicion(0, 2));
		b1.turno(new Posicion(0, 1));
	}
}
