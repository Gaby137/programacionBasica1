package ar.edu.buscaminas;

import java.util.Scanner;

public class menuBuscaminas {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int nivel = 0;
		System.out.println("Seleccione el nivel" + "\n1-Principiante" + "\n2-Intermedio" + "\n3-Avanzado");
		nivel = teclado.nextInt();

		switch (nivel) {
		case 1:
			jugadaX(teclado, 1);

			break;
		case 2:
			jugadaX(teclado, 2);
			break;
		case 3:
			jugadaX(teclado, 3);
			break;
		}

	}

	private static void jugadaX(Scanner teclado, int nivel) {
		Buscaminas b1 = new Buscaminas(nivel);
		b1.imprimirMatrizPorPunto();
		int x = 0;
		int y = 0;
		do {

			System.out.println("ingrese una posicion");
			x = teclado.nextInt();
			y = teclado.nextInt();
		} while (!b1.turno(new Posicion(x, y)));
	}

}
