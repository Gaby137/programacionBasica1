package ar.edu.buscaminas;

import java.util.ArrayList;
import java.util.List;

public class Buscaminas {
	private char[][] matriz;
	private int nivel;
	private int cantBombas;
	private int tam;
	private List<Posicion> listaPos;

	public Buscaminas(int nivel) {
		this.nivel = nivel;
		listaPos = new ArrayList<>();
		switch (nivel) {
		case 1:
			matriz = new char[3][3];
			cantBombas = 2;
			tam = 3;
			inicializaMat();
			break;
		case 2:
			matriz = new char[4][4];
			cantBombas = 4;
			tam = 4;
			inicializaMat();
			break;
		case 3:
			matriz = new char[5][5];
			cantBombas = 8;
			tam = 5;
			inicializaMat();
			break;

		}
	}

	public Boolean turno(Posicion p) {
		Boolean perdio = false;
		if (esBomba(p)) {
			System.out.println("perdiste");
			perdio = true;
		} else {
			listaPos.add(p);
			System.out.println("---------------------------------------");
			imprimirMatrizPorPunto();
			System.out.println("---------------------------------------");
		}
		return perdio;
	}

	public void imprimirMatrizPorPunto() {
		for (int i = 0; i < tam; i++) {
			for (int j = 0; j < tam; j++) {
				boolean encontrado = false;
				for (Posicion p : listaPos) {
					if (p.getX() == i && p.getY() == j) {
						encontrado = true;
						System.out.print(matriz[i][j]);
					}
				}
				if (!encontrado) {
					System.out.print('*');
				}

			}
			System.out.println();
		}

	}

	public Buscaminas(char[][] matriz0, int i) {
		matriz = matriz0;
		tam = i;
	}

	public void inicializaMat() {
		int max = tam - 1;
		int min = 0;
		int x = 0;
		int y = 0;
		int range = max - min + 1;
		for (int i = 0; i < cantBombas; i++) {
			x = (int) (Math.random() * range) + min;
			y = (int) (Math.random() * range) + min;
			matriz[x][y] = '*';
		}

		for (int i = 0; i < tam; i++) {
			for (int j = 0; j < tam; j++) {
				if (matriz[i][j] != '*') {
					Posicion p = new Posicion(i, j);
					int nroBom = cantidadDeMinasEnUnaPosicion(p);
//					System.out.println(nroBom);
					matriz[i][j] = Character.forDigit(nroBom, 10);

				}
			}
		}

	}

	public void imprimirMatriz() {
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz.length; j++) {

				System.out.print(matriz[i][j]);
			}
			System.out.println();
		}
	}

	public char[][] getMatriz() {
		return matriz;
	}

	public void setMatriz(char[][] matriz) {
		this.matriz = matriz;
	}

	public int getTam() {
		return tam;
	}

	public void setTam(int tam) {
		this.tam = tam;
	}

	public Boolean esBomba(Posicion p) {
		Boolean bomba = false;
		if (matriz[p.getX()][p.getY()] == '*') {
			bomba = true;
		}
		return bomba;
	}

	public int cantidadDeMinasEnUnaPosicion(Posicion p) {
		int cont = 0;
		if (matriz[p.getX()][p.getY()] != '*') {
			// puntos medio o centrales . El recorrido es de 8
			if ((p.getX() > 0 && p.getX() < tam - 1) && (p.getY() > 0 && p.getY() < tam - 1)) {
				// System.out.println("soy del medio");
				int i = p.getX() - 1;
				int j = p.getY() - 1;
				int limitI = i + 3;
				int limitJ = j + 3;
				while (i < limitI) {

					while (j < limitJ) {
						if (matriz[i][j] == '*') {
							cont++;
						}
						j++;
					}
					i++;
					j = j - 3;
				}
			} else {
// puntos esquina .El recorrido es de 3 
				if ((p.getX() == p.getY()) || (p.getX() == 0 && p.getY() == tam - 1)
						|| (p.getX() == tam - 1 && p.getY() == 0)) {

					// System.out.println("soy una esquina");

					int i = 0;
					int j = 0;
					final int COL = 2;
					final int FIL = 2;

					if (p.getX() == p.getY()) {
						if (p.getX() != 0) {
							i = p.getX() - 1;
							j = p.getY() - 1;
						}

						for (int a = i; a < i + FIL; a++) {
							for (int b = j; b < j + COL; b++) {
								if (matriz[a][b] == '*') {
									cont++;
								}
							}

						}
					} else {

						if (p.getX() == 0) {
							j = p.getY() - 1;
						} else {
							i = p.getX() - 1;
						}
						for (int a = i; a < i + FIL; a++) {
							for (int b = j; b < j + COL; b++) {
								if (matriz[a][b] == '*') {
									cont++;
								}

							}

						}
					}

				} else {
// puntos lateral .El recorrido es de 5
					if ((p.getX() == 0 && (p.getY() > 0 && p.getY() < tam - 1))
							|| (p.getY() == 0 && (p.getX() > 0 && p.getX() < tam - 1))
							|| (p.getX() == tam - 1 && (p.getY() > 0 && p.getY() < tam - 1))
							|| (p.getY() == tam - 1 && (p.getX() > 0 && p.getX() < tam - 1))) {
						// System.out.println("es lateral");
						int i = 0;
						int j = 0;
//						lateral vertical
						if (p.getY() == 0 || p.getY() == tam - 1) {

							final int COL = 2;
							final int FIL = 3;

							if (p.getY() == 0) {
								i = p.getX() - 1;
							} else {
								i = p.getX() - 1;
								j = p.getY() - 1;
							}

							for (int a = i; a < i + FIL; a++) {
								for (int b = j; b < j + COL; b++) {
									if (matriz[a][b] == '*') {
										cont++;
									}

								}

							}
						} else {
//							lateral horizontal
							if (p.getX() == 0 || p.getX() == tam - 1) {
								final int COL = 3;
								final int FIL = 2;

								if (p.getX() == 0) {
									i = p.getX();
									j = p.getY() - 1;
								} else {
									j = p.getY() - 1;
									i = p.getX() - 1;
								}

								for (int a = i; a < i + FIL; a++) {// recorre por fil
									for (int b = j; b < j + COL; b++) { // recorre las COL
										if (matriz[a][b] == '*') {
											cont++;
										}
									}

								}
							}

						}
					}
				}

			}

			// matriz[p.getX()][p.getY()] = Character.forDigit(cont, 10);
		}

		return cont;
	}

}
